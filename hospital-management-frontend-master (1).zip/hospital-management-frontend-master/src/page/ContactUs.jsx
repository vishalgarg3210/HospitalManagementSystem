const ContactUs = () => {
  return (
    <div className="text-color ms-5 me-5 mr-5 mt-3">
      <b>This is Contact Us component</b>
    </div>
  );
};

export default ContactUs;
